# Copyright (c) 2020, Frappe and Contributors
# See license.txt

# import frappe
import unittest


class TestWikiSettings(unittest.TestCase):
	pass
