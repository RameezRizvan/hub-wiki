# Copyright (c) 2023, Frappe and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestWikiFeedback(FrappeTestCase):
	pass
